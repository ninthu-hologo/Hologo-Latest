﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Hologo2.library;

namespace Hologo2
{

    [System.Serializable]
    public class assetBundleData : IdataObject
    {
        public int id;
        public string fileName;
        public attachablesClass experience;
    }
     

}


